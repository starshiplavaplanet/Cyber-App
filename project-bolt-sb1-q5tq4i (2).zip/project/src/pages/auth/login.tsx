import { AuthLayout } from '@/components/auth/auth-layout';
import { LoginForm } from '@/components/auth/login-form';

export function LoginPage() {
  return (
    <AuthLayout
      title="Sign in to your account"
      subtitle="Access your cybersecurity training platform"
    >
      <LoginForm />
    </AuthLayout>
  );
}