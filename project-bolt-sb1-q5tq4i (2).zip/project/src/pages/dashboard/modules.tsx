import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { ModuleCard } from '@/components/modules/module-card';
import { ModuleFilters } from '@/components/modules/module-filters';
import { mockTrainingModules } from '@/lib/data';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

export function ModulesPage() {
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredModules = mockTrainingModules.filter((module) => {
    const matchesLevel = selectedLevel === 'all' || module.level === selectedLevel;
    const matchesSearch = module.title
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const handleStart = (moduleId: string) => {
    console.log('Starting module:', moduleId);
  };

  const handleContinue = (moduleId: string) => {
    console.log('Continuing module:', moduleId);
  };

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">
            Training Modules
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Browse and complete cybersecurity training modules
          </p>
        </div>

        <div className="mt-6 px-4 sm:px-6 md:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <ModuleFilters
              selectedLevel={selectedLevel}
              onLevelChange={setSelectedLevel}
            />
            
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search modules..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredModules.map((module) => (
              <ModuleCard
                key={module.id}
                module={module}
                onStart={handleStart}
                onContinue={handleContinue}
              />
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}