import { useParams } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { ModuleContent } from '@/components/modules/module-content';
import { mockTrainingModules } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';

export function ModuleDetailsPage() {
  const { id } = useParams();
  const [currentContentIndex, setCurrentContentIndex] = useState(0);

  const module = mockTrainingModules.find((m) => m.id === id);

  if (!module) {
    return (
      <DashboardLayout>
        <div className="py-6 px-4 sm:px-6 lg:px-8">
          <p>Module not found</p>
        </div>
      </DashboardLayout>
    );
  }

  const currentContent = module.content[currentContentIndex];
  const isFirstContent = currentContentIndex === 0;
  const isLastContent = currentContentIndex === module.content.length - 1;

  const handleNext = () => {
    if (!isLastContent) {
      setCurrentContentIndex(currentContentIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (!isFirstContent) {
      setCurrentContentIndex(currentContentIndex - 1);
    }
  };

  const handleQuizComplete = () => {
    // TODO: Update module progress
    console.log('Quiz completed');
  };

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">
                {module.title}
              </h1>
              <p className="mt-1 text-sm text-gray-500">{module.description}</p>
            </div>
            <span
              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                module.level === 'beginner'
                  ? 'bg-green-100 text-green-800'
                  : module.level === 'intermediate'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {module.level}
            </span>
          </div>

          <div className="mt-8 bg-white shadow rounded-lg">
            <div className="px-6 py-8">
              <ModuleContent
                content={currentContent}
                onQuizComplete={handleQuizComplete}
              />
            </div>

            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-lg">
              <div className="flex justify-between">
                <Button
                  onClick={handlePrevious}
                  disabled={isFirstContent}
                  variant="secondary"
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={isLastContent}
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}