import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useQuery } from '@tanstack/react-query';
import { reports } from '@/lib/api';
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from 'recharts';

export function ReportsPage() {
  const { data: userMetrics } = useQuery({
    queryKey: ['user-metrics'],
    queryFn: reports.getUserMetrics,
  });

  const { data: phishingMetrics } = useQuery({
    queryKey: ['phishing-metrics'],
    queryFn: reports.getPhishingMetrics,
  });

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Reports</h1>
          <p className="mt-1 text-sm text-gray-500">
            Analytics and insights from training and phishing campaigns
          </p>

          <div className="mt-8 grid gap-8 md:grid-cols-2">
            {/* User Progress Chart */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                User Training Progress
              </h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userMetrics?.progressData || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="module" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="completionRate"
                      name="Completion Rate"
                      fill="#3B82F6"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Phishing Campaign Results */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Phishing Campaign Results
              </h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={phishingMetrics?.campaignData || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="clickRate"
                      name="Click Rate"
                      stroke="#EF4444"
                    />
                    <Line
                      type="monotone"
                      dataKey="reportRate"
                      name="Report Rate"
                      stroke="#10B981"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Training Completion Stats */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Training Completion Statistics
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Total Users</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {userMetrics?.totalUsers || 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Completed All Modules</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {userMetrics?.completedAll || 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Average Score</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {userMetrics?.averageScore || 0}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Active Users</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {userMetrics?.activeUsers || 0}
                  </p>
                </div>
              </div>
            </div>

            {/* Phishing Campaign Overview */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Phishing Campaign Overview
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Total Campaigns</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {phishingMetrics?.totalCampaigns || 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Active Campaigns</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {phishingMetrics?.activeCampaigns || 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Average Click Rate</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {phishingMetrics?.averageClickRate || 0}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Average Report Rate</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {phishingMetrics?.averageReportRate || 0}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}