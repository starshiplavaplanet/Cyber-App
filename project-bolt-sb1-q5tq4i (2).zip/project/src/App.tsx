import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LoginPage } from '@/pages/auth/login';
import { RegisterPage } from '@/pages/auth/register';
import { DashboardPage } from '@/pages/dashboard';
import { ModulesPage } from '@/pages/dashboard/modules';
import { ModuleDetailsPage } from '@/pages/dashboard/module/[id]';
import { ProtectedRoute } from '@/components/layout/protected-route';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dashboard/modules"
          element={
            <ProtectedRoute>
              <ModulesPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dashboard/module/:id"
          element={
            <ProtectedRoute>
              <ModuleDetailsPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/"
          element={
            <div className="min-h-screen bg-gray-100 flex items-center justify-center">
              <a
                href="/login"
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Go to Login
              </a>
            </div>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;