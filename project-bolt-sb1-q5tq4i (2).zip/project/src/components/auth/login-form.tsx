import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormField, FormLabel, FormError } from '@/components/ui/form';
import { LogIn } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { auth } from '@/lib/api';
import { useAuthStore } from '@/lib/store';
import { useNavigate } from 'react-router-dom';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

type LoginFormData = z.infer<typeof loginSchema>;

export function LoginForm() {
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const { mutate: loginUser, isPending } = useMutation({
    mutationFn: async (data: LoginFormData) => {
      const response = await auth.login(data.email, data.password);
      return response;
    },
    onSuccess: (data) => {
      setAuth(data.token, data.user);
      navigate('/dashboard');
    },
    onError: (error: any) => {
      if (error.response?.data?.message) {
        setError('root', { message: error.response.data.message });
      } else {
        setError('root', { message: 'Invalid email or password' });
      }
    },
  });

  return (
    <Form onSubmit={handleSubmit((data) => loginUser(data))}>
      <FormField>
        <FormLabel htmlFor="email">Email</FormLabel>
        <Input
          id="email"
          type="email"
          {...register('email')}
          aria-invalid={!!errors.email}
        />
        {errors.email && <FormError>{errors.email.message}</FormError>}
      </FormField>

      <FormField>
        <FormLabel htmlFor="password">Password</FormLabel>
        <Input
          id="password"
          type="password"
          {...register('password')}
          aria-invalid={!!errors.password}
        />
        {errors.password && <FormError>{errors.password.message}</FormError>}
      </FormField>

      {errors.root && <FormError>{errors.root.message}</FormError>}

      <div className="flex justify-between items-center">
        <a
          href="/forgot-password"
          className="text-sm text-blue-600 hover:text-blue-800"
        >
          Forgot Password?
        </a>
        <a href="/register" className="text-sm text-blue-600 hover:text-blue-800">
          Create Account
        </a>
      </div>

      <Button
        type="submit"
        className="w-full"
        disabled={isPending}
      >
        <LogIn className="mr-2 h-4 w-4" />
        {isPending ? 'Signing In...' : 'Sign In'}
      </Button>
    </Form>
  );
}