import { TrainingModule } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { BookOpen, Clock, Award } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ModuleCardProps {
  module: TrainingModule;
  onStart: (moduleId: string) => void;
  onContinue: (moduleId: string) => void;
}

export function ModuleCard({ module, onStart, onContinue }: ModuleCardProps) {
  const levelColors = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-yellow-100 text-yellow-800',
    advanced: 'bg-red-100 text-red-800',
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold text-gray-900">{module.title}</h3>
          <span
            className={cn(
              'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
              levelColors[module.level]
            )}
          >
            {module.level}
          </span>
        </div>
        
        <p className="mt-2 text-sm text-gray-600">{module.description}</p>
        
        <div className="mt-4 flex items-center text-sm text-gray-500">
          <Clock className="h-4 w-4 mr-1" />
          {module.duration}
        </div>

        {module.status !== 'not-started' && (
          <div className="mt-4">
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium text-gray-700">Progress</span>
              <span className="text-sm font-medium text-gray-700">
                {module.progress}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 rounded-full h-2"
                style={{ width: `${module.progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="mt-6">
          {module.status === 'not-started' ? (
            <Button
              onClick={() => onStart(module.id)}
              className="w-full"
            >
              <BookOpen className="h-4 w-4 mr-2" />
              Start Module
            </Button>
          ) : module.status === 'in-progress' ? (
            <Button
              onClick={() => onContinue(module.id)}
              className="w-full"
            >
              <BookOpen className="h-4 w-4 mr-2" />
              Continue
            </Button>
          ) : (
            <Button
              variant="secondary"
              className="w-full"
              disabled
            >
              <Award className="h-4 w-4 mr-2" />
              Completed
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}