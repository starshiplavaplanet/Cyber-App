import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Form, FormField, FormLabel } from '@/components/ui/form';
import { mockQuizzes } from '@/lib/data';
import { QuizFormData, quizSchema } from '@/lib/types';

interface ModuleQuizProps {
  quizId: string;
  onComplete?: () => void;
}

export function ModuleQuiz({ quizId, onComplete }: ModuleQuizProps) {
  const [showResults, setShowResults] = useState(false);
  const questions = mockQuizzes[quizId] || [];

  const form = useForm<QuizFormData>({
    resolver: zodResolver(quizSchema),
    defaultValues: {
      answers: {},
    },
  });

  const onSubmit = (data: QuizFormData) => {
    setShowResults(true);
    if (onComplete) {
      onComplete();
    }
  };

  const getScore = () => {
    const answers = form.getValues().answers;
    const correct = questions.filter(
      (q) => answers[q.id] === q.correctAnswer
    ).length;
    return Math.round((correct / questions.length) * 100);
  };

  return (
    <Form {...form} onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
      {questions.map((question) => (
        <FormField key={question.id}>
          <FormLabel className="text-lg font-medium">
            {question.question}
          </FormLabel>
          <div className="mt-4 space-y-2">
            {question.options.map((option) => (
              <div key={option} className="flex items-center">
                <input
                  type="radio"
                  id={`${question.id}-${option}`}
                  value={option}
                  {...form.register(`answers.${question.id}`)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                />
                <label
                  htmlFor={`${question.id}-${option}`}
                  className="ml-3 text-sm font-medium text-gray-700"
                >
                  {option}
                </label>
              </div>
            ))}
          </div>
        </FormField>
      ))}

      {showResults ? (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900">Quiz Results</h3>
          <p className="mt-2 text-sm text-gray-600">
            You scored {getScore()}%
          </p>
          <Button
            type="button"
            onClick={() => setShowResults(false)}
            className="mt-4"
          >
            Try Again
          </Button>
        </div>
      ) : (
        <Button type="submit" className="w-full">
          Submit Quiz
        </Button>
      )}
    </Form>
  );
}