import { Button } from '@/components/ui/button';

interface ModuleFiltersProps {
  selectedLevel: string;
  onLevelChange: (level: string) => void;
}

export function ModuleFilters({
  selectedLevel,
  onLevelChange,
}: ModuleFiltersProps) {
  const levels = ['all', 'beginner', 'intermediate', 'advanced'];

  return (
    <div className="flex flex-wrap gap-2">
      {levels.map((level) => (
        <Button
          key={level}
          variant={selectedLevel === level ? 'primary' : 'secondary'}
          size="sm"
          onClick={() => onLevelChange(level)}
        >
          {level.charAt(0).toUpperCase() + level.slice(1)}
        </Button>
      ))}
    </div>
  );
}