import { ModuleContent as ModuleContentType } from '@/lib/types';
import { ModuleQuiz } from './module-quiz';

interface ModuleContentProps {
  content: ModuleContentType;
  onQuizComplete?: () => void;
}

export function ModuleContent({ content, onQuizComplete }: ModuleContentProps) {
  if (content.type === 'quiz') {
    return <ModuleQuiz quizId={content.content} onComplete={onQuizComplete} />;
  }

  return (
    <div className="prose max-w-none">
      <h2 className="text-xl font-semibold mb-4">{content.title}</h2>
      <p className="text-gray-600">{content.content}</p>
    </div>
  );
}