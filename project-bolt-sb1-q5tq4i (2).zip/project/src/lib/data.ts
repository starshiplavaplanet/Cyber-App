import { TrainingModule, Question } from './types';

export const mockTrainingModules: TrainingModule[] = [
  {
    id: '1',
    title: 'Introduction to Cybersecurity',
    description: 'Learn the fundamentals of cybersecurity and basic security principles.',
    duration: '2 hours',
    level: 'beginner',
    progress: 0,
    status: 'not-started',
    content: [
      {
        id: '1-1',
        type: 'text',
        title: 'What is Cybersecurity?',
        content: 'Cybersecurity is the practice of protecting systems, networks, and programs from digital attacks...',
      },
      {
        id: '1-2',
        type: 'text',
        title: 'Common Security Threats',
        content: 'Understanding common security threats is crucial for maintaining a strong security posture...',
      },
      {
        id: '1-3',
        type: 'quiz',
        title: 'Module Quiz',
        content: 'quiz-1',
      },
    ],
  },
  {
    id: '2',
    title: 'Password Security Best Practices',
    description: 'Understanding password policies and implementing strong authentication.',
    duration: '1.5 hours',
    level: 'beginner',
    progress: 75,
    status: 'in-progress',
    content: [
      {
        id: '2-1',
        type: 'text',
        title: 'Password Best Practices',
        content: 'Creating and maintaining secure passwords is essential for protecting your accounts...',
      },
      {
        id: '2-2',
        type: 'quiz',
        title: 'Module Quiz',
        content: 'quiz-2',
      },
    ],
  },
  {
    id: '3',
    title: 'Phishing Attack Prevention',
    description: 'Identify and prevent phishing attacks in your organization.',
    duration: '2.5 hours',
    level: 'intermediate',
    progress: 100,
    status: 'completed',
    content: [
      {
        id: '3-1',
        type: 'text',
        title: 'Understanding Phishing Attacks',
        content: 'Phishing attacks are fraudulent attempts to obtain sensitive information...',
      },
      {
        id: '3-2',
        type: 'quiz',
        title: 'Module Quiz',
        content: 'quiz-3',
      },
    ],
  },
];

export const mockQuizzes: Record<string, Question[]> = {
  'quiz-1': [
    {
      id: 'q1-1',
      question: 'What is the primary goal of cybersecurity?',
      options: [
        'To make computers faster',
        'To protect systems from digital attacks',
        'To develop new software',
        'To improve internet speed',
      ],
      correctAnswer: 'To protect systems from digital attacks',
    },
    {
      id: 'q1-2',
      question: 'Which of the following is NOT a common security threat?',
      options: [
        'Phishing',
        'Malware',
        'Regular software updates',
        'Social engineering',
      ],
      correctAnswer: 'Regular software updates',
    },
  ],
};