import { useAuthStore } from './store';

export function isAuthenticated() {
  const token = useAuthStore.getState().token;
  return !!token;
}

export function getUserRole() {
  const user = useAuthStore.getState().user;
  return user?.role || 'user';
}

export function logout() {
  useAuthStore.getState().clearAuth();
}