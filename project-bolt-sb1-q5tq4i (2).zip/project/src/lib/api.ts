import axios from 'axios';
import { useAuthStore } from './store';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  login: async (email: string, password: string) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },
  register: async (email: string, password: string) => {
    const response = await api.post('/auth/register', { email, password });
    return response.data;
  },
};

export const modules = {
  getAll: async () => {
    const response = await api.get('/modules');
    return response.data;
  },
  getById: async (id: string) => {
    const response = await api.get(`/modules/${id}`);
    return response.data;
  },
  create: async (data: any) => {
    const response = await api.post('/modules', data);
    return response.data;
  },
  update: async (id: string, data: any) => {
    const response = await api.put(`/modules/${id}`, data);
    return response.data;
  },
  delete: async (id: string) => {
    const response = await api.delete(`/modules/${id}`);
    return response.data;
  },
};

export const phishing = {
  getAll: async () => {
    const response = await api.get('/phishing');
    return response.data;
  },
  create: async (data: any) => {
    const response = await api.post('/phishing', data);
    return response.data;
  },
  getById: async (id: string) => {
    const response = await api.get(`/phishing/${id}`);
    return response.data;
  },
};

export const reports = {
  getUserMetrics: async () => {
    const response = await api.get('/reports/users');
    return response.data;
  },
  getPhishingMetrics: async () => {
    const response = await api.get('/reports/phishing');
    return response.data;
  },
};