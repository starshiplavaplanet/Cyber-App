import { z } from 'zod';

export interface TrainingModule {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  progress: number;
  status: 'not-started' | 'in-progress' | 'completed';
  content: ModuleContent[];
}

export interface ModuleContent {
  id: string;
  type: 'text' | 'video' | 'quiz';
  title: string;
  content: string;
}

export const quizSchema = z.object({
  answers: z.record(z.string()),
});

export type QuizFormData = z.infer<typeof quizSchema>;

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
}